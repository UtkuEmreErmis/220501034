import sqlite3
import random

db_path = "/mnt/data/ders_programi.db"
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS dersler (
    kod TEXT PRIMARY KEY,
    ad TEXT NOT NULL,
    sinif INTEGER NOT NULL,
    hoca TEXT NOT NULL,
    kisi_sayisi INTEGER NOT NULL
);
""")


cursor.execute("""
CREATE TABLE IF NOT EXISTS derslikler (
    derslik_id TEXT PRIMARY KEY,
    kapasite INTEGER NOT NULL,
    statu TEXT NOT NULL
);
""")


dersler_data = [
    ("MAT110", "Matematik I", 1, "Vildan Yazıcı"),
    ("FIZ110", "Fizik I", 1, "Saliha Elmas"),
    ("MAT125", "Lineer Cebir", 1, "H. Tarık Duru"),
    ("BLM111", "Bilgisayar Mühendisliğine Giriş", 1, "Nevcihan Duru"),
    ("BLM112", "Bilgisayar Programlama I", 1, "Ulaş Vural"),
    ("BML113", "Bilgisayar Lab I", 1, "Ulaş Vural"),
    ("DİL101", "İngilizce", 1, "Sunmaz Arslan"),
    ("SEC101", "Temel Bilgi Teknolojileri", 1, "Mehmet Kara"),
    ("MAT211", "Diferansiyel Denklemler", 2, "Vildan Yazıcı"),
    ("MAT213", "Ayrık Matematik", 2, "Vildan Yazıcı"),
    ("BLM211", "Nesneye Yönelik Programlama", 2, "Nur Banu Albayrak"),
    ("BLM213", "Veritabanı Yönetim Sistemleri", 2, "Nur Banu Albayrak"),
    ("BLM215", "Temel Elektronik ve Uygulamaları", 2, "H. Tarık Duru"),
    ("BLM217", "Programlama Lab-I", 2, "Nevcihan Duru"),
    ("SEC102", "Kullanıcı Deneyimi Tasarımı", 2, "Ulaş Vural"),
    ("MAT310", "Sayısal Yöntemler", 3, "Vildan Yazıcı"),
    ("BLM311", "Bilgisayar Mimarisi ve Organizasyonu", 3, "Elif Pınar Hacıbeyoğlu"),
    ("BLM313", "Yazılım Mühendisliği", 3, "Ercan Ölçer"),
    ("BLM315", "Yazılım Lab-I", 3, "Tarık Duru"),
    ("BLM317", "Yapay Zeka", 3, "Ulaş Vural"),
    ("SEC103", "Kriptolojiye Giriş", 3, "İsmet Karaduman"),
    ("SEC104", "Proje ve Portföy Yönetimi", 3, "Mehmet Kara"),
    ("BLM411", "Programlama Dilleri", 4, "Nur Banu Albayrak"),
    ("BLM413", "Biçimsel Diller ve Otomatlar", 4, "Fulya Akdeniz"),
    ("BLM415", "Araştırma Problemleri", 4, "Tüm MDBF Öğretim Üyeleri"),
    ("BLM417", "İş Sağlığı ve Güvenliği-I", 4, "Ahmet Şen"),
    ("SEC105", "Girişimcilik ve İnovasyon", 4, "Ahmet Şen"),
    ("YZM215", "Yazılım Gereksinim Analizi", 2, "Nur Banu Albayrak"),
    ("YZM313", "Yazılım Test ve Kalite", 3, "Elif Pınar Hacıbeyoğlu"),
    ("YZM315", "Yazılım Lab-I", 3, "Tarık Duru"),
    ("MAT220", "Sayısal Yöntemler", 3, "Vildan Yazıcı"),
    ("YZM326", "Bilgisayar Mimarisi ve Organizasyonu", 3, "Elif Pınar Hacıbeyoğlu"),
    ("YZM319", "Web Programlama", 3, "Fulya Akdeniz"),
    ("YZM424", "Yapay Zeka", 4, "İsmet Karaduman"),
    ("YZM411", "Programlama Dilleri", 4, "Nur Banu Albayrak"),
    ("YZM413", "Biçimsel Diller ve Otomatlar", 4, "Fulya Akdeniz"),
    ("YZM415", "Araştırma Problemleri", 4, "Tüm MDBF Öğretim Üyeleri"),
    ("YZM417", "İş Sağlığı ve Güvenliği-I", 4, "Ahmet Şen")
]

dersler_data_guncel = []

for kod, ad, sinif, hoca in dersler_data:
    kisi_sayisi = 20 if "Lab" in ad else random.randint(40, 110)
    dersler_data_guncel.append((kod, ad, sinif, hoca, kisi_sayisi))

cursor.executemany("INSERT INTO dersler (kod, ad, sinif, hoca, kisi_sayisi) VALUES (?, ?, ?, ?, ?)", dersler_data_guncel)

derslikler_data = [
    ("M101", 66, "NORMAL"),
    ("M201", 141, "NORMAL"),
    ("M301", 141, "NORMAL"),
    ("S101", 138, "NORMAL"),
    ("S201", 60, "NORMAL"),
    ("S202", 60, "NORMAL"),
    ("D101", 87, "NORMAL"),
    ("D102", 87, "NORMAL"),
    ("D103", 88, "NORMAL"),
    ("D104", 56, "NORMAL"),
    ("AMFİ A", 143, "NORMAL"),
    ("BİL.LAB 1", 40, "LAB"),
    ("BİL.LAB.2", 30, "LAB"),
    ("KÜÇÜK LAB", 20, "LAB")
]

cursor.executemany("INSERT INTO derslikler (derslik_id, kapasite, statu) VALUES (?, ?, ?)", derslikler_data)

conn.commit()
conn.close()
