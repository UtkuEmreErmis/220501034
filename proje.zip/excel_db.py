import sqlite3

db_path = "/mnt/data/excel_database.db"
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS bilgisayar_muhendisligi (
    gun_saat_sinif TEXT PRIMARY KEY,
    ders TEXT,
    derslik TEXT,
    excelhucre TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS yazilim_muhendisligi (
    gun_saat_sinif TEXT PRIMARY KEY,
    ders TEXT,
    derslik TEXT,
    excelhucre TEXT
)
""")

gunler = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma"]
saatler = [
    "09:00-10:00", "10:00-11:00", "11:00-12:00", "12:00-13:00", "13:00-14:00",
    "14:00-15:00", "15:00-16:00", "16:00-17:00"
]
siniflar = ["1. Sinif", "2. Sinif", "3. Sinif", "4. Sinif"]
sutunlar = ["C", "D", "E", "F"]

bilgisayar_muhendisligi_veriler = []
satir = 4
for gun in gunler:
    for saat in saatler:
        for idx, sinif in enumerate(siniflar):
            hucre = f"{satir}{sutunlar[idx]}"
            bilgisayar_muhendisligi_veriler.append((f"{gun} {saat} {sinif}", None, None, hucre))
        satir += 1

yazilim_muhendisligi_veriler = []
satir = 48
for gun in gunler:
    for saat in saatler:
        for idx, sinif in enumerate(siniflar):
            hucre = f"{satir}{sutunlar[idx]}"
            yazilim_muhendisligi_veriler.append((f"{gun} {saat} {sinif}", None, None, hucre))
        satir += 1

cursor.executemany("INSERT INTO bilgisayar_muhendisligi VALUES (?, ?, ?, ?)", bilgisayar_muhendisligi_veriler)
cursor.executemany("INSERT INTO yazilim_muhendisligi VALUES (?, ?, ?, ?)", yazilim_muhendisligi_veriler)

conn.commit()
conn.close()
