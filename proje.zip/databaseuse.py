import sqlite3

conn = sqlite3.connect("ders_programi.db")
cursor = conn.cursor()

cursor.execute("SELECT * FROM dersler")
dersler = cursor.fetchall()

cursor.execute("SELECT * FROM derslikler")
derslikler = cursor.fetchall()


for ders in dersler:
    print(ders)

print("\n")

for derslik in derslikler:
    print(derslik)

print("\n")

conn.close()

#  "dersler" tablosu için
#  kod, ad, sinif, hoca, kisi_sayisi

#  "derslik" tablosu için
#  derslik_id, kapasite, statu

# ---

conn = sqlite3.connect("excel_database.db")
cursor = conn.cursor()

cursor.execute("SELECT * FROM Bilgisayar_Muhendisligi")
pc_muh = cursor.fetchall()

for i in pc_muh:
    print(i)

print("\n")

cursor.execute("SELECT * FROM Yazilim_Muhendisligi")
yaz_muh = cursor.fetchall()

for i in yaz_muh:
    print(i)



conn.close()

# Yazilim_Muhendisligi ve Bilgisayar_Muhendisligi tabloları
# "gun_saat_sinif" sütunu
# "ders" sütunu
# "derslik" sütunu
# "excelhucre" sütunu
