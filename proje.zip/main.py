import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3

selected_data = {"bolum": ""}


def fetch_data_from_db(table, column, condition_column=None, condition_value=None):
    conn = sqlite3.connect("ders_programi.db")
    cursor = conn.cursor()
    if condition_column and condition_value:
        cursor.execute(f"SELECT {column} FROM {table} WHERE {condition_column} = ?", (condition_value,))
    else:
        cursor.execute(f"SELECT {column} FROM {table}")
    data = [row[0] for row in cursor.fetchall()]
    conn.close()
    return data
def save_to_excel_database():
    conn = sqlite3.connect("excel_database.db")
    cursor = conn.cursor()

    table_name = selected_data["bolum"]
    primary_key = f"{selected_data['gun']} {selected_data['saat']} {selected_data['sinif']}. Sinif"

    cursor.execute(f"SELECT gun_saat_sinif FROM {table_name} WHERE gun_saat_sinif = ?", (primary_key,))
    result = cursor.fetchone()

    if result:
        cursor.execute(f"UPDATE {table_name} SET ders = ?, derslik = ? WHERE gun_saat_sinif = ?",
                       (selected_data['ders'], selected_data['derslik'], primary_key))
        conn.commit()
        messagebox.showinfo("Başarı", "Veriler başarıyla güncellendi!")
    else:
        messagebox.showerror("Hata", "Eşleşen kayıt bulunamadı!")
    conn.close()

def delete_from_excel_database():
    conn = sqlite3.connect("excel_database.db")
    cursor = conn.cursor()
    table_name = selected_data["bolum"]
    primary_key = f"{selected_data['gun']} {selected_data['saat']} {selected_data['sinif']}. Sinif"
    cursor.execute(f"SELECT gun_saat_sinif FROM {table_name} WHERE gun_saat_sinif = ?", (primary_key,))
    result = cursor.fetchone()
    if result:
        cursor.execute(f"UPDATE {table_name} SET ders = NULL, derslik = NULL WHERE gun_saat_sinif = ?", (primary_key,))
        conn.commit()
        messagebox.showinfo("Başarı", "Ders bilgisi başarıyla silindi!")
    else:
        messagebox.showerror("Hata", "Eşleşen kayıt bulunamadı!")
    conn.close()


def open_lesson_selection():
    lesson_window = tk.Toplevel(root)
    lesson_window.title("Ders ve Derslik Seçimi")
    lesson_window.geometry("300x300")
    tk.Label(lesson_window, text="Ders Seçin:").pack(pady=5)
    lessons = fetch_data_from_db("dersler", "kod")
    lesson_var = tk.StringVar()
    lesson_dropdown = ttk.Combobox(lesson_window, textvariable=lesson_var, values=lessons, state="readonly")
    lesson_dropdown.pack(pady=5)
    tk.Label(lesson_window, text="Derslik Seçin:").pack(pady=5)
    classrooms = fetch_data_from_db("derslikler", "derslik_id")
    classroom_var = tk.StringVar()
    classroom_dropdown = ttk.Combobox(lesson_window, textvariable=classroom_var, values=classrooms, state="readonly")
    classroom_dropdown.pack(pady=5)

    def confirm_lesson_selection():
        lesson = lesson_var.get()
        classroom = classroom_var.get()
        if not lesson or not classroom:
            messagebox.showerror("Hata", "Lütfen tüm alanları doldurun!")
            return

        kisi_sayisi = fetch_data_from_db("dersler", "kisi_sayisi", "kod", lesson)[0]
        kapasite = fetch_data_from_db("derslikler", "kapasite", "derslik_id", classroom)[0]
        if kapasite >= kisi_sayisi:
            selected_data["ders"] = lesson
            selected_data["derslik"] = classroom
            save_to_excel_database()
        else:
            messagebox.showerror("Hata", "Seçilen derslik kapasitesi yetersiz!")
    confirm_button = tk.Button(lesson_window, text="Bu hazneye ders ekle", command=confirm_lesson_selection)
    confirm_button.pack(pady=10)
    delete_button = tk.Button(lesson_window, text="Bu hazneyi sil", command=delete_from_excel_database)
    delete_button.pack(pady=5)


def open_selection_screen(program_name):
    selection_window = tk.Toplevel(root)
    selection_window.title(f"{program_name} - Ders Seçimi")
    selection_window.geometry("300x300")

    selected_data[
        "bolum"] = "Bilgisayar_Muhendisligi" if program_name == "Bilgisayar Mühendisliği" else "Yazilim_Muhendisligi"
    tk.Label(selection_window, text="Gün Seçin:").pack(pady=5)
    days = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma"]
    day_var = tk.StringVar()
    day_dropdown = ttk.Combobox(selection_window, textvariable=day_var, values=days, state="readonly")
    day_dropdown.pack(pady=5)
    tk.Label(selection_window, text="Saat Seçin:").pack(pady=5)
    hours = ["09:00-10:00", "10:00-11:00", "11:00-12:00", "13:00-14:00", "14:00-15:00", "15:00-16:00", "16:00-17:00"]
    hour_var = tk.StringVar()
    hour_dropdown = ttk.Combobox(selection_window, textvariable=hour_var, values=hours, state="readonly")
    hour_dropdown.pack(pady=5)
    tk.Label(selection_window, text="Sınıf Seçin:").pack(pady=5)
    classes = ["1", "2", "3", "4"]
    class_var = tk.StringVar()
    class_dropdown = ttk.Combobox(selection_window, textvariable=class_var, values=classes, state="readonly")
    class_dropdown.pack(pady=5)

    def confirm_selection():
        if not day_var.get() or not hour_var.get() or not class_var.get():
            messagebox.showerror("Hata", "Lütfen tüm alanları doldurun!")
            return
        selected_data["gun"] = day_var.get()
        selected_data["saat"] = hour_var.get()
        selected_data["sinif"] = class_var.get()
        open_lesson_selection()
    confirm_button = tk.Button(selection_window, text="Onayla", command=confirm_selection)
    confirm_button.pack(pady=10)

root = tk.Tk()
root.title("Ders Seçim Ekranı")
root.geometry("400x200")
tk.Button(root, text="Bilgisayar Mühendisliği Programı",
          command=lambda: open_selection_screen("Bilgisayar Mühendisliği")).pack(pady=10)
tk.Button(root, text="Yazılım Mühendisliği Programı",
          command=lambda: open_selection_screen("Yazılım Mühendisliği")).pack(pady=10)

root.mainloop()
