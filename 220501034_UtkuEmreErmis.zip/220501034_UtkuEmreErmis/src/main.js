import { createTool } from "./menu.js";
import { WireManager } from "./wire.js";

// Shared variables
export let imgs = []; // Array to hold gate images
export let gate = []; // Array to hold gate objects
export let logicInput = []; // Array to hold logic input objects
export let logicOutput = []; // Array to hold logic output objects
export let colorMouseOver = [0, 0x7B, 0xFF]; // Color for mouse over highlight
export let wireMng; // Wire manager instance

// Preload images
export function preload() {
 const gateNames = ['BUFFER', 'NOT', 'AND', 'NAND', 'OR', 'NOR', 'XOR', 'XNOR'];
 imgs = gateNames.map(name => loadImage(`src/imgs/${name}.svg`));
}

// Setup for p5.js and global managers
export function setup() {
 const height = windowHeight - 90; // Calculate canvas height
 let canvas = createCanvas(windowWidth - 115, height, P2D); // Create canvas
 canvas.parent('canvas'); // Attach canvas to DOM element with id 'canvas'
 wireMng = new WireManager(); // Initialize wire manager

 // Set up the keypress event listener
 window.addEventListener('keydown', (event) => {
  if (event.key === 'Backspace') {
   deleteElement();
  }
 });
}

// Handle window resize event
export function windowResized() {
 const height = windowHeight - 90;
 resizeCanvas(windowWidth - 115, height);
}

// Draw all items in the provided array
function drawItems(items) {
 items.forEach(item => item.draw());
}

// Handle mouse actions for all items in the provided array
function handleMouseAction(items, action) {
 items.forEach(item => item[action]());
}

// Global draw loop
export function draw() {
 background(0xFF); // Set background color
 stroke(0); // Set stroke color
 strokeWeight(2); // Set stroke weight
 fill(0xFF); // Set fill color
 rect(0, 0, width, height); // Draw a rectangle to fill the canvas

 wireMng.draw(); // Draw wires
 [gate, logicInput, logicOutput].forEach(drawItems); // Draw gates, logic inputs, and logic outputs
}

// Handle mouse pressed event
export function mousePressed() {
 [gate, logicInput, logicOutput].forEach(items => handleMouseAction(items, 'mousePressed'));
}

// Handle mouse released event
export function mouseReleased() {
 [gate, logicInput, logicOutput].forEach(items => handleMouseAction(items, 'mouseReleased'));
}

// Handle double clicked event
export function doubleClicked() {
 handleMouseAction(logicInput, 'doubleClicked');
}

// Handle mouse clicked event
export function mouseClicked() {
 [gate, logicInput, logicOutput].forEach(items => handleMouseAction(items, 'mouseClicked'));
 wireMng.mouseClicked();
}

// Delete the marked element
export function deleteElement() {
 [gate, logicInput, logicOutput, wireMng.wires].forEach(items => {
  for (let i = items.length - 1; i >= 0; i--) { // Iterate in reverse order to safely remove elements
   if (items[i].isMarked) { // Check if the item is marked
    items[i].destroy(); // Destroy the item
    items.splice(i, 1); // Remove the item from the array
   }
  }
 });
}


// reset board
export function reset() {
 [gate, logicInput, logicOutput, wireMng.wires].forEach(items => {
  for (let i = items.length - 1; i >= 0; i--) { // Iterate in reverse order to safely remove elements
   items[i].destroy(); // Destroy the item
   items.splice(i, 1); // Remove the item from the array
  }
 });
}


// Assign functions to window object for global access
window.preload = preload;
window.setup = setup;
window.windowResized = windowResized;
window.draw = draw;
window.createTool = createTool;
window.mousePressed = mousePressed;
window.mouseReleased = mouseReleased;
window.doubleClicked = doubleClicked;
window.mouseClicked = mouseClicked;
window.reset = reset;
