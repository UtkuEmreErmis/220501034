import { imgs, wireMng } from "./main.js";
import { INPUT_STATE, gateType } from "./enums.js";
import { Node } from "./node.js";
import { colorMouseOver } from "./main.js";

// Gate class definition
export class Gate {
  // Constructor to initialize the Gate object
  constructor(strType) {
    this.name = strType;
    this.type = this.convertToType(strType);
    this.width = imgs[this.type].width;
    this.height = imgs[this.type].height;
    this.posX = mouseX - this.width / 2;
    this.posY = mouseY - this.height / 2;
    this.isSpawned = false;
    this.offsetMouseX = 0;
    this.offsetMouseY = 0;
    this.isMoving = false;
    this.isSaved = false;
    this.isMarked = false;

    this.input = [new Node(this.posX, this.posY + 15)];

    // Add second input node for gates other than NOT and BUFFER
    if (this.type != gateType.NOT && this.type != gateType.BUFFER) {
      this.input.push(new Node(this.posX, this.posY + this.height - 15));
      this.input[0].setSibiling(this.input[1]); // Set sibling relationship between input nodes
      this.input[1].setSibiling(this.input[0]); // Set sibling relationship between input nodes
    }

    this.output = new Node(this.posX + this.width, this.posY + this.height / 2, true);
    this.nodeStartID = this.input[0].id;
  }

  // Destroy this gate and its nodes
  destroy() {
    this.input.forEach(input => input.destroy());
    delete this.input;
    this.output.destroy();
    delete this.output;
  }

  // Draw the gate and its nodes
  draw() {
    if (!this.isSpawned) {
      this.posX = mouseX - (this.width / 2); // Update X position
      this.posY = mouseY - (this.height / 2); // Update Y position
    }

    if (this.isMoving) {
      this.posX = mouseX + this.offsetMouseX; // Update X position while moving
      this.posY = mouseY + this.offsetMouseY; // Update Y position while moving
    }

    // Update position of input nodes based on gate type
    if (this.type == gateType.NOT || this.type == gateType.BUFFER) {
      this.input[0].updatePosition(this.posX, this.posY + this.height / 2);
    } else {
      this.input[0].updatePosition(this.posX, this.posY + 15);
      this.input[1].updatePosition(this.posX, this.posY + this.height - 15);
    }

    this.output.updatePosition(this.posX + this.width, this.posY + this.height / 2); // Update output node position

    // Highlight gate if mouse is over or gate is marked
    if (this.isMouseOver() || this.isMarked) {
      noFill();
      strokeWeight(2);
      stroke(colorMouseOver[0], colorMouseOver[1], colorMouseOver[2]);
      rect(this.posX, this.posY, this.width, this.height + 20); // Draw highlight rectangle
    }

    image(imgs[this.type], this.posX, this.posY); // Draw gate image

    for (let i = 0; i < this.input.length; i++) {
      this.input[i].draw(); // Draw input nodes
    }

    this.generateOutput(); // Generate output value
    this.output.draw(); // Draw output node

    noStroke();
    fill(0);
    textSize(12);
    textStyle(NORMAL);
    textAlign(CENTER, BASELINE);
    text(this.name, this.posX + this.width / 2, this.posY + this.height + 15);
    textAlign(LEFT, BASELINE);
  }

  // Refresh node IDs
  refreshNodes() {
    let currentID = this.nodeStartID;
    this.input[0].setID(currentID);
    currentID++;
    if (this.type != gateType.NOT) {
      this.input[1].setID(currentID);
      currentID++;
    }
    this.output.setID(currentID);
  }

  // Generate gate output
  generateOutput() {
    if (this.allInputsConnected()) {
      this.output.setValue(this.calculateValue());
    } else {
      this.output.setValue(false);
    }
  }


  // Check if all inputs are connected
  allInputsConnected() {
    return this.input.every(input =>
      input.inputState === INPUT_STATE.TAKEN &&
      wireMng.isConnected(input)
    );
  }


  // Calculate gate output based on type
  calculateValue() {
    switch (this.type) {
      case gateType.BUFFER:
        return this.input[0].getValue();
      case gateType.NOT:
        return !this.input[0].getValue();
      case gateType.AND:
        return this.input[0].getValue() && this.input[1].getValue();
      case gateType.NAND:
        return !(this.input[0].getValue() && this.input[1].getValue());
      case gateType.OR:
        return this.input[0].getValue() || this.input[1].getValue();
      case gateType.NOR:
        return !(this.input[0].getValue() || this.input[1].getValue());
      case gateType.XOR:
        return this.input[0].getValue() ^ this.input[1].getValue();
      case gateType.XNOR:
        return !(this.input[0].getValue() ^ this.input[1].getValue());
    }
  }

  // Convert string to gate type
  convertToType(str) {
    return gateType[str];
  }

  // Check if mouse is over the gate
  isMouseOver() {
    return mouseX > this.posX && mouseX < this.posX + this.width &&
      mouseY > this.posY && mouseY < this.posY + this.height;
  }

  // Handle mouse pressed event
  mousePressed() {
    if (!this.isSpawned) {
      this.posX = mouseX - this.width / 2;
      this.posY = mouseY - this.height / 2;
      this.isSpawned = true;
      return;
    }

    if (this.isMouseOver()) {
      this.isMoving = true;
      this.offsetMouseX = this.posX - mouseX;
      this.offsetMouseY = this.posY - mouseY;
    }
  }

  // Handle mouse released event
  mouseReleased() {
    this.isMoving = false;
  }

  // Handle mouse clicked event
  mouseClicked() {
    this.isMarked = this.isMouseOver();
    let result = this.isMarked;

    this.input.forEach(input => {
      result |= input.mouseClicked();
    });

    result |= this.output.mouseClicked();
    return result;
  }
}
