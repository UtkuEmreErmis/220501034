import { INPUT_STATE } from "./enums.js";
import { wireMng } from "./main.js";

export let nodeList = []; // List to hold all nodes
let currentID = 0; // Variable to track current node ID

// Node class definition
export class Node {
 // Constructor to initialize the Node object
 constructor(posX, posY, isOutput = false, value = false) {
  this.diameter = 10; // Diameter of the node
  this.value = value; // Value of the node (true/false)
  this.posX = posX; // X position of the node
  this.posY = posY; // Y position of the node
  this.isOutput = isOutput; // Flag to check if the node is an output
  this.padding = this.diameter + 15; // Padding around the node
  this.inputState = INPUT_STATE.FREE; // Initial input state of the node
  this.isAlive = true; // Flag to check if the node is active
  this.sibilingNode = null; // Reference to the sibling node
  this.id = currentID++; // Assign unique ID to the node
  nodeList[this.id] = this; // Add node to the nodeList
 }


 // destroy node
 destroy() {
  // Find all wires connected to this node
  const connectedWires = wireMng.wires.filter(wire => wire.startNode.id === this.id || (wire.endNode && wire.endNode.id === this.id));

  // Remove all connected wires and update counterpart nodes
  connectedWires.forEach(wire => {
   if (wire.startNode.id === this.id && wire.endNode) {
    wire.endNode.setValue(false);
    wire.endNode.setInputState(INPUT_STATE.FREE);
   } else if (wire.endNode && wire.endNode.id === this.id) {
    wire.startNode.setValue(false);
    wire.startNode.setInputState(INPUT_STATE.FREE);
   }
   wire.destroy()
  });

  // Mark this node as no longer alive
  this.isAlive = false;

  // Remove this node from the node list
  delete nodeList[this.id];
 }

 // Draw the node
 draw() {
  fillValue(this.value);
  stroke(0);
  strokeWeight(4);
  circle(this.posX, this.posY, this.diameter);
  if (this.isMouseOver()) {
   fill(128, 128);
   noStroke();
   circle(this.posX, this.posY, this.padding);
  }
 }

 // Set a new ID for the node
 setID(newID) {
  delete nodeList[this.id];
  this.id = newID;
  nodeList[this.id] = this;
  if (this.id > currentID) currentID = this.id + 1;
 }

 // Set the input state of the node
 setInputState(state) {
  this.inputState = state;
 }

 // Set the sibling node
 setSibiling(sibilingNode) {
  this.sibilingNode = sibilingNode;
 }

 // Get the sibling node
 getSibiling() {
  return this.sibilingNode;
 }

 // Get the value of the node
 getValue() {
  return this.value;
 }

 // Set the value of the node
 setValue(value) {
  this.value = value;
 }

 // Update the position of the node
 updatePosition(posX, posY) {
  this.posX = posX;
  this.posY = posY;
 }

 // Check if the mouse is over the node
 isMouseOver() {
  return dist(mouseX, mouseY, this.posX, this.posY) < this.padding / 2;
 }

 // Handle mouse click event
 mouseClicked() {
  if (this.isMouseOver() && (this.inputState == INPUT_STATE.FREE || this.isOutput)) {
   wireMng.addNode(this);
   return true;
  }
  return false;
 }
}

// Set the fill color based on the node value
export function fillValue(value) {
 value ? fill(255, 193, 7) : fill(52, 58, 64);
}