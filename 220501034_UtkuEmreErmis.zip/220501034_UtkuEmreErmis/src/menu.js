import { Gate } from "./gate.js";
import { Input } from "./input.js";
import { Output } from "./output.js";
import { gate, logicInput, logicOutput } from "./main.js";

export function createTool(elTool) {
 const tool = elTool.getAttribute("tool");
 const isGate = elTool.getAttribute("isGate") !== null;

 if (isGate) {
  gate.push(new Gate(tool));
  return;
 }

 if (tool === "INPUT") {
  logicInput.push(new Input());
 }

 if (tool === "OUTPUT") {
  logicOutput.push(new Output());
 }

 if (tool === "LED") {
  logicOutput.push(new Output(true))
 }
}



