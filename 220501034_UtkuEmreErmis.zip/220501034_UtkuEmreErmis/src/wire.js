import { INPUT_STATE } from "./enums.js";
import { colorMouseOver, logicInput, gate, wireMng } from "./main.js";


/**
 * Represents a wire.
 * Implementation tips from here: https://reactflow.dev/api-reference/components/base-edge
 */
export class Wire {
  /**
   * Constructor to initialize the Wire object
   * @param {Object} startNode - The starting node of the wire
   */
  constructor(startNode) {
    this.startNode = startNode; // Starting node of the wire
    this.endNode = null; // Ending node of the wire
    this.startID = startNode.id; // ID of the starting node
    this.endID = null; // ID of the ending node
    this.endX = mouseX; // X position of the wire's end
    this.endY = mouseY; // Y position of the wire's end
    this.width = 8; // Width of the wire
    this.isMarked = false; // Flag to check if wire is marked
  }

  /**
   * Delete the wire and free start node and end node
   */
  destroy() {
    if (wireMng.wires.filter(wire => wire.startNode.id === this.startNode.id).length === 1) {
      this.startNode.setInputState(INPUT_STATE.FREE);
    }
    if (this.endNode) {
      this.endNode.setValue(false);
      this.endNode.setInputState(INPUT_STATE.FREE);
    }
  }

  /**
  * Function to draw wire
  * @returns {boolean} - Whether the wire was drawn successfully
  */
  draw() {
    stroke(0);
    strokeWeight(this.width / 2);

    if (!this.endNode && this.startNode.isAlive) {
      this.drawBezier(this.startNode.posX, this.startNode.posY, mouseX, mouseY);
    } else if (this.startNode.isAlive && this.endNode.isAlive) {
      this.calculateValue();
      noFill();
      stroke(this.isMouseOver() || this.isMarked ? colorMouseOver : 0);
      this.drawBezier(this.startNode.posX, this.startNode.posY, this.endNode.posX, this.endNode.posY);
      this.drawActiveWire();
    } else {
      this.endNode.setValue(false);
      return false;
    }
    return true;
  }

  /**
  * Draw the active wire if both startNode and endNode are true
  */
  drawActiveWire() {
    if (this.startNode.getValue() && this.endNode.getValue()) {
      strokeWeight(1);
      stroke(255, 193, 7);
      this.drawBezier(this.startNode.posX, this.startNode.posY, this.endNode.posX, this.endNode.posY);
    }
  }

  /**
   * Draw a bezier curve between start and end points
   * @param {number} startX - X coordinate of the start point
   * @param {number} startY - Y coordinate of the start point
   * @param {number} endX - X coordinate of the end point
   * @param {number} endY - Y coordinate of the end point
   */
  drawBezier(startX, startY, endX, endY) {
    bezier(
      startX, startY,
      startX + 50, startY,
      endX - 50, endY,
      endX, endY
    );
  }

  /**
   * Calculate value for the wire
   */
  calculateValue() {
    if ((this.startNode.isOutput && this.endNode.isOutput) ||
      (!this.startNode.isOutput && !this.endNode.isOutput)) {
      const value = this.startNode.getValue() || this.endNode.getValue();
      this.startNode.setValue(value);
      this.endNode.setValue(value);
    } else {
      this.endNode.setValue(this.startNode.getValue());
    }
  }

  /**
   * Check if mouse is over the wire
   * @returns {boolean} - Whether the mouse is over the wire
   */
  isMouseOver() {
    if (!this.startNode.isAlive || !this.endNode?.isAlive) return false;

    const distance1 = dist(this.startNode.posX, this.startNode.posY, mouseX, mouseY);
    const distance2 = dist(this.endNode.posX, this.endNode.posY, mouseX, mouseY);
    const wireLength = dist(this.startNode.posX, this.startNode.posY, this.endNode.posX, this.endNode.posY);

    return distance1 + distance2 >= wireLength - this.width / 20 &&
      distance1 + distance2 <= wireLength + this.width / 20;
  }

  /**
   * Get wire start node
   * @returns {Object} - The starting node of the wire
   */
  getStartNode() {
    return this.startNode;
  }

  /**
   * Change wire end coordinates
   * @param {number} endX - X coordinate of the wire's end
   * @param {number} endY - Y coordinate of the wire's end
   */
  updateEnd(endX, endY) {
    this.endX = endX;
    this.endY = endY;
  }

  /**
   * Set this wire's end node
   * @param {Object} endNode - The ending node of the wire
   */
  setEndNode(endNode) {
    if (endNode.isOutput) {
      [this.startNode, this.endNode] = [endNode, this.startNode];
    } else {
      this.endNode = endNode;
    }
    this.startNode.setInputState(INPUT_STATE.TAKEN);
    this.endNode.setInputState(INPUT_STATE.TAKEN);

    this.startID = this.startNode.id;
    this.endID = this.endNode.id;
  }
}

/**
 * WireManager class to manage multiple wires
 */
export class WireManager {
  constructor() {
    this.wires = []; // List of wires
    this.isWireOpen = false; // Flag to check if a wire is open
  }

  /**
   * Draw all wires
   */
  draw() {
    this.wires = this.wires.filter(wire => wire.draw());
  }

  /**
   * Add a node to the wire
   * @param {Object} node - The node to be added
   */
  addNode(node) {
    if (!this.isWireOpen) {
      this.wires.push(new Wire(node));
      this.isWireOpen = true;
    } else {
      const lastWire = this.wires[this.wires.length - 1];
      const startNode = lastWire.getStartNode();
      const canConnect = node !== startNode && (startNode.isOutput !== node.isOutput || node.getSibling() === startNode);

      if (canConnect) {
        lastWire.setEndNode(node);
      } else {
        this.wires.pop();
      }
      this.isWireOpen = false;
    }
  }

  /**
   * Handle mouse click event
   */
  mouseClicked() {
    this.wires.forEach(wire => {
      wire.isMarked = wire.isMouseOver();
    });
  }

  isConnected(targetNode) {
    for (let input of logicInput) {
      if (input.output.inputState === INPUT_STATE.TAKEN) {
        if (this.traceConnection(input.output, targetNode)) {
          return true;
        }
      }
    }
    return false;
  }

  traceConnection(currentNode, targetNode, visitedNodes = new Set()) {
    if (!currentNode || visitedNodes.has(currentNode.id)) return false;

    visitedNodes.add(currentNode.id);

    if (currentNode.id === targetNode.id) {
      return true;
    }

    // Find all wires connected to the current node
    let connectedWires = this.wires.filter(wire => wire.startNode.id === currentNode.id);

    if (connectedWires.length === 0) {
      return false;
    }

    for (let wire of connectedWires) {
      const endNode = wire.endNode;
      if (endNode) {
        const g = gate.find(g => g?.input.find(n => n.id === endNode?.id));

        if (endNode.id === targetNode.id || this.traceConnection(g?.output, targetNode, visitedNodes)) {
          return true;
        }
      }
    }

    return false;
  }
}
