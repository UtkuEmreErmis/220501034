export const gateType =
{
 BUFFER: 0,
 NOT: 1,
 AND: 2,
 NAND: 3,
 OR: 4,
 NOR: 5,
 XOR: 6,
 XNOR: 7,
};

export const INPUT_STATE =
{
 FREE: 0,
 TAKEN: 1,
}