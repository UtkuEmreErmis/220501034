import { Node, fillValue } from "./node.js";
import { colorMouseOver } from "./main.js";

// Output class definition
export class Output {
 // Constructor to initialize the Output object
 constructor(isLED = false) {
  this.value = false; // Initial value of the output
  this.isLED = isLED;
  this.posX = mouseX; // X position of the output
  this.posY = mouseY; // Y position of the output
  this.diameter = 25; // Diameter of the output
  this.isSpawned = false; // Flag to check if output is spawned
  this.isMoving = false; // Flag to check if output is being moved
  this.offsetMouseX = 0; // Offset for moving the output
  this.offsetMouseY = 0; // Offset for moving the output
  this.input = new Node(this.posX - 30, this.posY, false, this.value); // Input node
  this.nodeStartID = this.input.id; // Initial node ID
  this.isSaved = false; // Flag to check if output is saved
  this.isMarked = false; // Flag to check if output is marked
 }

 // Destroy the output and its input node
 destroy() {
  this.input.destroy();
  delete this.input;
 }

 // Draw the output and its input node
 draw() {
  if (!this.isSpawned) {
   this.posX = mouseX;
   this.posY = mouseY;
  } else if (!this.isSaved) {
   this.isSaved = true;
  }

  if (this.isMoving) {
   this.posX = mouseX + this.offsetMouseX;
   this.posY = mouseY + this.offsetMouseY;
  }

  this.input.updatePosition(this.posX - 30, this.posY);
  this.value = this.input.getValue();

  if (this.isLED) {
   this.value ? fill(255, 0, 0) : fill(255, 255, 255)

  } else {

   fillValue(this.value);
  }

  stroke(this.isMouseOver() || this.isMarked ? colorMouseOver : 0);
  strokeWeight(4);
  line(this.posX, this.posY, this.posX - 30, this.posY);
  circle(this.posX, this.posY, this.diameter);

  this.input.draw();

  noStroke();
  fill(0);
  textSize(12);
  textStyle(NORMAL);
  if (this.isLED) {
   text('LED', this.posX - 30, this.posY + 25);
  }
  else {
   text('OUTPUT', this.posX - 30, this.posY + 25);
  }

  if (!this.isLED) {
   textSize(18);
   textStyle(this.value ? BOLD : NORMAL);
   fill(this.value ? 0 : 255);
   text(this.value ? '1' : '0', this.posX - this.diameter / 4, this.posY + this.diameter / 4);
  }
 }

 // Refresh the node ID
 refreshNodes() {
  let currentID = this.nodeStartID;
  this.input.setID(currentID);
 }

 // Check if the mouse is over the output
 isMouseOver() {
  return dist(mouseX, mouseY, this.posX, this.posY) < this.diameter / 2;
 }

 // Handle mouse pressed event
 mousePressed() {
  if (!this.isSpawned) {
   this.posX = mouseX;
   this.posY = mouseY;
   this.isSpawned = true;
   return;
  }

  if (this.isMouseOver()) {
   this.isMoving = true;
   this.offsetMouseX = this.posX - mouseX;
   this.offsetMouseY = this.posY - mouseY;
  }
 }

 // Handle mouse released event
 mouseReleased() {
  this.isMoving = false;
 }

 // Handle mouse clicked event
 mouseClicked() {
  this.isMarked = this.isMouseOver();
  if (this.isMouseOver() || this.input.isMouseOver()) {
   this.input.mouseClicked();
   return true;
  }
  return false;
 }
}
