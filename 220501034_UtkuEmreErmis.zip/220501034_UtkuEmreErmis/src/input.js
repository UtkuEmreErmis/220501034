import { Node, fillValue } from "./node.js";
import { colorMouseOver, wireMng } from "./main.js";

// Input class definition
export class Input {
 // Constructor to initialize the Input object
 constructor() {
  this.value = false; // Initial value of the input
  this.posX = mouseX; // X position of the input
  this.posY = mouseY; // Y position of the input
  this.diameter = 25; // Diameter of the input
  this.isSpawned = false; // Flag to check if input is spawned
  this.isMoving = false; // Flag to check if input is being moved
  this.offsetMouseX = 0; // Offset for moving the input
  this.offsetMouseY = 0; // Offset for moving the input
  this.output = new Node(this.posX + 30, this.posY, true, this.value); // Output node
  this.nodeStartID = this.output.id; // Initial node ID
  this.isSaved = false; // Flag to check if input is saved
  this.isMarked = false; // Flag to check if input is marked
 }

 // Destroy the input and its output node
 destroy() {
  this.output.destroy();
  delete this.output;
 }

 // Draw the input and its output node
 draw() {
  if (!this.isSpawned) {
   this.posX = mouseX;
   this.posY = mouseY;
  } else if (!this.isSaved) {
   this.isSaved = true;
  }

  fillValue(this.value);

  if (this.isMoving) {
   this.posX = mouseX + this.offsetMouseX;
   this.posY = mouseY + this.offsetMouseY;
  }

  stroke(this.isMouseOver() || this.isMarked ? colorMouseOver : 0);
  strokeWeight(4);
  line(this.posX, this.posY, this.posX + 30, this.posY);
  circle(this.posX, this.posY, this.diameter);

  this.output.updatePosition(this.posX + 30, this.posY);
  this.output.setValue(this.value);
  this.output.draw();

  noStroke();
  fill(0);
  textSize(12);
  textStyle(NORMAL);
  text('INPUT', this.posX - 20, this.posY + 25);

  textSize(18);
  textStyle(this.value ? BOLD : NORMAL);
  fill(this.value ? 0 : 255);
  text(this.value ? '1' : '0', this.posX - this.diameter / 4, this.posY + this.diameter / 4);
 }

 // Refresh the node ID
 refreshNodes() {
  this.output.setID(this.nodeStartID);
 }

 // Check if the mouse is over the input
 isMouseOver() {
  return dist(mouseX, mouseY, this.posX, this.posY) < this.diameter / 2;
 }

 // Handle mouse pressed event
 mousePressed() {
  if (!this.isSpawned) {
   this.posX = mouseX;
   this.posY = mouseY;
   this.isSpawned = true;
  } else if (this.isMouseOver()) {
   this.isMoving = true;
   this.offsetMouseX = this.posX - mouseX;
   this.offsetMouseY = this.posY - mouseY;
  }
 }

 // Handle mouse released event
 mouseReleased() {
  if (this.isMoving) {
   this.isMoving = false;
  }
 }

 // Handle double clicked event
 doubleClicked() {
  if (this.isMouseOver()) {
   this.value = !this.value;
  }
 }

 // Handle mouse clicked event
 mouseClicked() {
  this.isMarked = this.isMouseOver();
  if (this.isMouseOver() || this.output.isMouseOver()) {
   this.output.mouseClicked();
   return true;
  }
  return false;
 }

 // Toggle the value of the input
 toggle() {
  this.value = !this.value;
 }
}
